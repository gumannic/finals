<h1 class="text-center">Willkommen zur Movie Watchlist App</h1>
<p class="text-center">Verwalte deine Lieblingsfilme schnell und einfach.</p>
